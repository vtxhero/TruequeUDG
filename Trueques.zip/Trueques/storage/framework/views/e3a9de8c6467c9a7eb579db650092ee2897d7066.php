

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
                <h2>Vista</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="<?php echo e(url('cliente')); ?>"> Back</a>
        </div>
    </div>
    <table class="table table-bordered">
        <tr>
            <th>Nombre:</th>
            <td><?php echo e($cliente->nombre); ?></td>
        </tr>
        <tr>
            <th>Telefono:</th>
            <td><?php echo e($cliente->id); ?></td>
        </tr>
        <tr>
            <th>Email:</th>
            <td>$<?php echo e($cliente->email); ?></td>
        </tr>
		<tr>
            <th>Direccion:</th>
            <td>$<?php echo e($cliente->direccion); ?></td>
        </tr>

    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sertec2\resources\views/cliente/view.blade.php ENDPATH**/ ?>