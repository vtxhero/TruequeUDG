

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
            <h2>Update Clientes</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="<?php echo e(url('cliente')); ?>"> Back</a>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('cliente.update',$cliente->id)); ?>" >
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="txtTelefono">Telefono:</label>
            <input type="number" class="form-control" id="txtTelefono" placeholder="Telefono" name="txtTelefono" value="<?php echo e($cliente->id); ?>">
        </div>
		<div class="form-group">
            <label for="txtNombre">Nombre:</label>
            <input type="text" class="form-control" id="txtNombre" placeholder="Nombre" name="txtNombre" value="<?php echo e($cliente->nombre); ?>">
        </div>
		<div class="form-group">
            <label for="txtEmail">Email:</label>
            <input type="email" class="form-control" id="txtEmail" placeholder="Email" name="txtEmail" value="<?php echo e($cliente->email); ?>">
        </div>
		<div class="form-group">
            <label for="txtDireccion">Direccion:</label>
            <input type="text" class="form-control" id="txtDireccion" placeholder="Direccion" name="txtDireccion" value="<?php echo e($cliente->direccion); ?>">
        </div>
        
		
        <button type="submit" class="btn btn-default">Enviar</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sertec2\resources\views/cliente/edit.blade.php ENDPATH**/ ?>