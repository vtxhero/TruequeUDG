

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
            <h2>Agregar Reporte</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="<?php echo e(url('ordenser')); ?>"> Regresar</a>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Error!</strong> Formato incorrecto.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
	<form action="<?php echo e(route('ordenser.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="txtFolio">Folio:</label>
            <input type="text" class="form-control" id="txtFolio" placeholder="Folio" name="txtFolio" >
        </div>
		
		<div class="form-group">
            <label for="txtFecha">Fecha:</label>
            <input type="text" class="form-control" id="txtFecha" placeholder="Fecha" name="txtFecha" >
        </div>
		
		<div class="form-group">
            <label for="txtFalla">Falla:</label>
            <input type="text" class="form-control" id="txtFalla" placeholder="Falla" name="txtFalla" >
        </div>
		
		<div class="form-group">
            <label for="txtIdempleado">Empleado:</label>
            <input type="text" class="form-control" id="txtIdempleado" placeholder="Empleado" name="txtIdempelado" >
        </div>
		
		<div class="form-group">
            <label for="txtDiagnostico">Diagnostico:</label>
            <input type="text" class="form-control" id="txtDiagnostico" placeholder="Diagnostico" name="txtDiagnostico" >
        </div>
		<div class="form-group">
            <label for="txtObservacion">Observacion:</label>
            <input type="text" class="form-control" id="txtDiagnostico" placeholder="Diagnostico" name="txtDiagnostico" >
        </div>
		<div class="form-group">
            <label for="txtCosto">Costo:</label>
            <input type="text" class="form-control" id="txtCosto" placeholder="Costo" name="txtCosto" >
        </div>
        <div class="form-group">
            <label for="txtEntrega">Entrega:</label>
            <input type="text" class="form-control" id="txtEntrega" placeholder="Entrega" name="txtEntrega" >
        </div>
		<div class="form-group">
            <label for="txtStatus">Status:</label>
            <input type="text" class="form-control" id="txtStatus" placeholder="Status" name="txtStatus" >
        </div>
		
        <button type="submit" class="btn btn-default">Enviar</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ordenser.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sertec2\resources\views/ordenser/create.blade.php ENDPATH**/ ?>