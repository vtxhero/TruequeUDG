<!DOCTYPE html>
<html>
<head>
    <title>SERTEC</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        .btn-primary{
            background-color: darkgray
        }
    </style>

</head>
<body>
    <div class="jumbotron text-center">
        <h1>SERTEC</h1>
    </div>
    <div class="container">

        <div class="btn-group btn-group-justified">
            <a href="<?php echo e(url('/cliente')); ?>" class="btn btn-primary" >Clientes</a>
        </div>
        <div class="btn-group btn-group-justified">
            <a href="<?php echo e(url('/empleado')); ?>" class="btn btn-primary" >Empleados</a>
            <a href="<?php echo e(url('/insumo')); ?>" class="btn btn-primary" >Insumos</a>
        </div>

        <div class="btn-group btn-group-justified">
            <a href="<?php echo e(url('/gerente')); ?>" class="btn btn-primary" >Gerente</a>
            <a href="<?php echo e(url('/tecnico')); ?>" class="btn btn-primary" >Tecnico</a>
            <a href="<?php echo e(url('/almacenista')); ?>" class="btn btn-primary" >Almacenista</a>
        </div>

    </div>
</body>
</html><?php /**PATH C:\laragon\www\sertec2\resources\views/inicio.blade.php ENDPATH**/ ?>