<div class="jumbotron text-center">
  	<h2>Agregar cliente</h2>
</div>

<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="<?php echo e(url('/clientes')); ?>" method="post" enctype="multipart/form-data" style="width: 85%; margin-left: 55px" >
		<?php echo $__env->make('clientes.form',['Modo' => 'crear' ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alexis\Desktop\ProyectoIngSoft\resources\views/clientes/create.blade.php ENDPATH**/ ?>