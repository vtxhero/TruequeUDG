<div class="jumbotron text-center">
		<h1>Empleados</h1>
</div>

<?php $__env->startSection('content'); ?>
<div class="container">
  	<div class="btn-group btn-group-justified"  style="margin-left: 150px; margin-right: 15px" >
  		<a href="<?php echo e(url('/empleados/create')); ?>" class="btn btn-primary" style="width: 45%; background-color:darkgray">Agregar</a>
  		<div class="input-group" style=" width: 55%">
			<input type="text" class="form-control" placeholder="Buscar por ID">
			<div class="input-group-btn">
			   	<button class="btn btn-default" type="submit">
		    		<i class="glyphicon glyphicon-search"></i>
		      	</button>
		    </div>
	 	 </div>      
  	</div>
	<div class="container">
		<table class="table table-striped">
    		<thead>
     			<tr>
     				<th>#</th>
	        		<th>Nombre</th>
	        		<th>Puesto</th>
	        		<th>Sueldo diario</th>
	        		<th>Fecha de contratacion</th>
	        		<th>Direccion</th>
	        		<th>Telefono</th>
	        		<th>Id empleado</th>
	        		<th></th>
        		</tr>
    		</thead>
		    <tbody>
		    	<?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    	<tr>
			    		<td><?php echo e($loop->iteration); ?></td>
			    		<td><?php echo e($empleado->nombre); ?></td>
			    		<td><?php echo e($empleado->puesto); ?></td>
			    		<td><?php echo e($empleado->sueldo); ?></td>
			    		<td><?php echo e($empleado->updated_at); ?></td>
			    		<td><?php echo e($empleado->direccion); ?></td>
			    		<td><?php echo e($empleado->telefono); ?></td>
			    		<td><?php echo e($empleado->id); ?></td>
			    		<td>
			    			<a href="<?php echo e(url('/empleados/'.$empleado->id.'/edit')); ?>">
			    				<button type="submit" class="btn btn-default">Editar</button>
			    			</a>
			    			<form method="POST" action="<?php echo e(url('/empleados/'.$empleado->id)); ?>" style="display:inline" >
			    			<?php echo e(csrf_field()); ?>

			    			<?php echo e(method_field('DELETE')); ?>

			    			<button type="submit" class="btn btn-default" onclick="return confirm('Borrar¿?');" >Borrar</button>			    				
			    			</form>
			    		</td>
			        </tr>     
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </tbody>
		</table>
		<div style="text-align: center">
			<?php echo e($empleados->links()); ?>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sertec2\resources\views/empleados/index.blade.php ENDPATH**/ ?>