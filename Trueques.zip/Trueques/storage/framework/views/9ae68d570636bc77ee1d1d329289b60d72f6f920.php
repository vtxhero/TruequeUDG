

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
                <h2>Vista</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="<?php echo e(url('insumo')); ?>"> Back</a>
        </div>
    </div>
    <table class="table table-bordered">
        <tr>
            <th>Nombre:</th>
            <td><?php echo e($insumo->nombre); ?></td>
        </tr>
        <tr>
            <th>Descripcion:</th>
            <td><?php echo e($insumo->descripcion); ?></td>
        </tr>
        <tr>
            <th>Precio:</th>
            <td>$<?php echo e($insumo->precio); ?></td>
        </tr>

    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('insumo.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sertec2\resources\views/insumo/view.blade.php ENDPATH**/ ?>