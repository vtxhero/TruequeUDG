

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
            <h2>Update Empleados</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="<?php echo e(url('empleados')); ?>"> Back</a>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('empleado.update',$empleado->id)); ?>" >
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="txtNombre">Nombre:</label>
            <input type="text" class="form-control" id="txtNombre" placeholder="Nombre" name="txtNombre" value="<?php echo e($empleado->nombre); ?>">
        </div>
		<div class="form-group">
            <label for="txtTipo">Tipo:</label>
			<select type="text" class="form-control" id="txtTipo" placeholder="Tipo" name="txtTipo" value="<?php echo e($empleado->tipo); ?>">
				<option value="Gerente">Gerente</option>
				<option value="Tecnico">Tecnico</option>
				<option value="Almacenista">Almacenista</option>
			</select>
        </div>
        <div class="form-group">
            <label for="txtTelefono">Telefono:</label>
            <input type="number" class="form-control" id="txtTelefono" placeholder="Telefono" name="txtTelefono" value="<?php echo e($empleado->telefono); ?>">
        </div>
		<div class="form-group">
            <label for="txtEmail">Email:</label>
            <input type="email" class="form-control" id="txtEmail" placeholder="Email" name="txtEmail" value="<?php echo e($empleado->email); ?>">
        </div>
		
        <button type="submit" class="btn btn-default">Enviar</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('empleado.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sertec2\resources\views/empleado/edit.blade.php ENDPATH**/ ?>