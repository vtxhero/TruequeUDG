<?php echo e(csrf_field()); ?>

<label for="Nombre ">Nombre completo</label>
<input type="Text" class="form-control" id="Nombre" placeholder="Nombre completo"name="nombre"
value="<?php echo e(isset($cliente->nombre)?$cliente->nombre:old('nombre')); ?>">
<?php echo $errors->first('nombre', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="RFC">RFC</label>
<input type="Text" class="form-control" id="RFC" placeholder="RFC"name="rfc"
value="<?php echo e(isset($cliente->rfc)?$cliente->rfc:old('rfc')); ?>">
<?php echo $errors->first('rfc', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="Bonificaciones">Bonificaciones</label>
<input type="number" class="form-control" id="Bonificaciones" placeholder="Bonificaciones"name="bonificacion"
value="<?php echo e(isset($cliente->bonificacion)?$cliente->bonificacion:old('bonificacion')); ?>">
<?php echo $errors->first('bonificaciones', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="Email">Email</label>
<input type="Email" class="form-control" id="Email" placeholder="Email"name="email"
value="<?php echo e(isset($cliente->email)?$cliente->email:old('email')); ?>">
<?php echo $errors->first('email', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="Direccion">Direccion</label>
<input type="Text" class="form-control" id="Direccion" placeholder="Direccion"name="direccion"
value="<?php echo e(isset($cliente->direccion)?$cliente->direccion:old('direccion')); ?>">
<?php echo $errors->first('direccion', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="Telefono">Telefono</label>
<input type="Text" class="form-control" id="Telefono" placeholder="Telefono"name="telefono"
value="<?php echo e(isset($cliente->telefono)?$cliente->telefono:old('telefono')); ?>">
<?php echo $errors->first('telefono', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<br/>
<button type="submit" class="btn btn-default"><?php echo e($Modo=='crear' ? 'Añadir' : 'Guardar cambios'); ?></button>

<a href="<?php echo e(url('/clientes')); ?>">
  <button type="button" class="btn btn-default">Cancelar</button>
</a><?php /**PATH C:\Users\alexis\Desktop\ProyectoIngSoft\resources\views/clientes/form.blade.php ENDPATH**/ ?>