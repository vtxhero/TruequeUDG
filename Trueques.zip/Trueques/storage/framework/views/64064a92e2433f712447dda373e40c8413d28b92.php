

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
                <h2>Vista</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="<?php echo e(url('empleado')); ?>"> Back</a>
        </div>
    </div>
    <table class="table table-bordered">
        <tr>
            <th>Nombre:</th>
            <td><?php echo e($empleado->nombre); ?></td>
        </tr>
        <tr>
            <th>Tipo:</th>
            <td><?php echo e($empleado->tipo); ?></td>
        </tr>
		<tr>
            <th>Telefono:</th>
            <td><?php echo e($empleado->telefono); ?></td>
        </tr>
		<tr>
            <th>Email:</th>
            <td><?php echo e($empleado->email); ?></td>
        </tr>

    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('empleado.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sertec2\resources\views/empleado/view.blade.php ENDPATH**/ ?>