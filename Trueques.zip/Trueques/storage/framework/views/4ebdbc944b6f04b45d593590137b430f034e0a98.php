

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
                <h2>Lista de insumos</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-success" href="<?php echo e(route('insumoor.create')); ?>">Agregar</a>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Nombre</th>
            <th>Precio</th>
            
            <th>Cantidad</th>
        </tr>
        <?php
            $i = 0;
        ?>
        <?php $__currentLoopData = $insumoors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insumoor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($insumoor->idinsumo); ?></td>
                <td><?php echo e($insumoor->precio); ?></td>
                <td><?php echo e($insumoor->cantidad); ?></td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('insumoor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sertec2\resources\views/insumoor/list.blade.php ENDPATH**/ ?>