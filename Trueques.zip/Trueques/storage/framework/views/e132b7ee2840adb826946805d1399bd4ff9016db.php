<?php echo e(csrf_field()); ?>

<label for="Nombre ">Nombre completo</label>
<input type="Text" Name="nombre" class="form-control <?php echo e($errors->has('nombre')?'is-invalid':''); ?>" id="Nombre" placeholder="Nombre completo" value="<?php echo e(isset($empleado->nombre)?$empleado->nombre:old('nombre')); ?>">  
<?php echo $errors->first('nombre', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="Puesto">Puesto</label>
<input type="Text" Name="puesto"class="form-control <?php echo e($errors->has('puesto')?'is-invalid':''); ?>" id="Puesto" placeholder="Puesto" value="<?php echo e(isset($empleado->puesto)?$empleado->puesto:old('puesto')); ?>"> 
<?php echo $errors->first('puesto', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>



<label for="Sueldo diario">Sueldo diario</label>
<input type="number" Name="sueldo" class="form-control <?php echo e($errors->has('sueldo')?'is-invalid':''); ?>" id="sueldo" placeholder="Sueldo diario" value="<?php echo e(isset($empleado->sueldo)?$empleado->sueldo:old('sueldo')); ?>">
<?php echo $errors->first('sueldo', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="Direccion">Direccion</label>
<input type="Text" Name="direccion" class="form-control <?php echo e($errors->has('direccion')?'is-invalid':''); ?>" id="Direccion" placeholder="Direccion" value="<?php echo e(isset($empleado->direccion)?$empleado->direccion:old('direccion')); ?>">
<?php echo $errors->first('direccion', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="Telefono">Telefono</label>
<input type="Text" Name="telefono" class="form-control <?php echo e($errors->has('telefono')?'is-invalid':''); ?>" id="Telefono" placeholder="Telefono" value="<?php echo e(isset($empleado->telefono)?$empleado->telefono:old('telefono')); ?>">
<?php echo $errors->first('telefono', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<br/>
<button type="submit" class="btn btn-default"><?php echo e($Modo=='crear' ? 'Añadir' : 'Guardar cambios'); ?></button>

<a href="<?php echo e(url('/empleados')); ?>">
  <button type="button" class="btn btn-default">Cancelar</button>
</a>
  
<?php /**PATH C:\Users\alexis\Desktop\ProyectoIngSoft\resources\views/empleados/form.blade.php ENDPATH**/ ?>