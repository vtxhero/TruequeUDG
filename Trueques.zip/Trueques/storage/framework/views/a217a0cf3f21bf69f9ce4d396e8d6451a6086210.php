<!DOCTYPE html>
<html >
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- CSRF TOKEN -->
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title>VETSIS</title>

	<!--Scripts-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

 	<!-- Styles -->
 	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body>
	<div id="app">
		<div class="btn-group btn-group-justified">
			<a href="<?php echo e(url('/')); ?>" class="btn btn-primary" style="background-color: darkgray">Inicio</a>
            <a href="<?php echo e(url('/clientes')); ?>" class="btn btn-primary" style="background-color: darkgray">Clientes</a>
            <a href="<?php echo e(url('/empleados')); ?>" class="btn btn-primary" style="background-color: darkgray">Empleados</a>
            <a href="<?php echo e(url('/productos')); ?>" class="btn btn-primary" style="background-color: darkgray">Productos</a>
        </div>
        <br/>
        <br/>
        <br/>
		<main class="py-4">
			<?php echo $__env->yieldContent('content'); ?>
		</main>
	</div>
</body>
</html><?php /**PATH C:\Users\alexis\Desktop\ProyectoIngSoft\resources\views/layouts/app.blade.php ENDPATH**/ ?>