<div class="jumbotron text-center">
    <h2>Editar producto</h2>
</div>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<form action="<?php echo e(url('/productos/'.$producto->id)); ?>" method="post" enctype="multipart/form-data" style="width: 85%; margin-left: 55px" >
			<?php echo e(method_field('PATCH')); ?>

        	<?php echo $__env->make('productos.form',['Modo' => 'modificar' ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alexis\Desktop\ProyectoIngSoft\resources\views/productos/edit.blade.php ENDPATH**/ ?>