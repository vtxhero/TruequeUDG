<div class="jumbotron text-center">
  	<h1>insumos</h1>
</div>

<?php $__env->startSection('content'); ?>
<div class="row">
  		<div class="btn-group btn-group-justified"  style="margin-left: 150px; margin-right: 15px" >
      		<a href="<?php echo e(url('/insumos/create')); ?>" class="btn btn-primary" style="width: 45%; background-color:darkgray">Agregar</a>
      		     
      	</div>
		<div class="container">
			<table class="table table-striped">
	    		<thead>
	     			<tr>
	     				<th>#</th>
		        		<th>Nombre</th>
		        		<th>Descripcion</th>
		        		<th>Precio</th>
	        			<th></th>
	        		</tr>
	    		</thead>
			    <tbody>
			    	<?php $__currentLoopData = $insumo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insumos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    	<tr>
				    		<td><?php echo e($loop->iteration); ?></td>
				    		<td><?php echo e($insumo->nombre); ?></td>
				    		<td><?php echo e($insumo->descripcion); ?></td>
				    		<td><?php echo e($insumo->idinsumo); ?></td>
				    		<td><?php echo e($insumo->precio); ?></td>
				        	<td>
				    			<a href="<?php echo e(url('/insumos/'.$insumo->idinsumo.'/edit')); ?>">
				    				<button type="submit" class="btn btn-default">Editar</button>
				    			</a>
				    			<form method="POST" action="<?php echo e(url('/insumos/'.$insumo->id)); ?>" style="display:inline" >
				    			<?php echo e(csrf_field()); ?>

				    			<?php echo e(method_field('DELETE')); ?>

				    			<button type="submit" class="btn btn-default" onclick="return confirm('Borrar¿?');" >Borrar</button>			    				
				    			</form>
		    				</td>
				        </tr>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
			    </tbody>
			</table>
			<div style="text-align: center">
				<?php echo e($insumo->links()); ?>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sertec2\resources\views/insumos/index.blade.php ENDPATH**/ ?>