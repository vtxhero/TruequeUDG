<div class="jumbotron text-center">
  	<h1>Productos</h1>
</div>

<?php $__env->startSection('content'); ?>
<div class="row">
  		<div class="btn-group btn-group-justified"  style="margin-left: 150px; margin-right: 15px" >
      		<a href="<?php echo e(url('/productos/create')); ?>" class="btn btn-primary" style="width: 45%; background-color:darkgray">Agregar</a>
      		<div class="input-group" style=" width: 55%">
				<input type="text" class="form-control" placeholder="Buscar por ID">
				<div class="input-group-btn">
				   	<button class="btn btn-default" type="submit">
			    		<i class="glyphicon glyphicon-search"></i>
			      	</button>
			    </div>
		 	 </div>      
      	</div>
		<div class="container">
			<table class="table table-striped">
	    		<thead>
	     			<tr>
	     				<th>#</th>
		        		<th>Nombre</th>
		        		<th>Categoria</th>
		        		<th>Existencias</th>
		        		<th>Descripcion</th>
		        		<th>Id producto</th>
		        		<th>Marca</th>
		        		<th>Precio</th>
	        			<th></th>
	        		</tr>
	    		</thead>
			    <tbody>
			    	<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    	<tr>
				    		<td><?php echo e($loop->iteration); ?></td>
				    		<td><?php echo e($producto->nombre); ?></td>
				    		<td><?php echo e($producto->categoria); ?></td>
				    		<td><?php echo e($producto->existencias); ?></td>
				    		<td><?php echo e($producto->descripcion); ?></td>
				    		<td><?php echo e($producto->id); ?></td>
				    		<td><?php echo e($producto->marca); ?></td>
				    		<td><?php echo e($producto->precio); ?></td>
				        	<td>
				    			<a href="<?php echo e(url('/productos/'.$producto->id.'/edit')); ?>">
				    				<button type="submit" class="btn btn-default">Editar</button>
				    			</a>
				    			<form method="POST" action="<?php echo e(url('/productos/'.$producto->id)); ?>" style="display:inline" >
				    			<?php echo e(csrf_field()); ?>

				    			<?php echo e(method_field('DELETE')); ?>

				    			<button type="submit" class="btn btn-default" onclick="return confirm('Borrar¿?');" >Borrar</button>			    				
				    			</form>
		    				</td>
				        </tr>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
			    </tbody>
			</table>
			<div style="text-align: center">
				<?php echo e($productos->links()); ?>

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sertec2\resources\views/productos/index.blade.php ENDPATH**/ ?>