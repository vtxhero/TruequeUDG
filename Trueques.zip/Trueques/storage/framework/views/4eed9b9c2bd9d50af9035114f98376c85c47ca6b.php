<?php echo e(csrf_field()); ?>

<label for="Nombre ">Nombre</label>
<input type="Text" class="form-control" id="Nombre" placeholder="Nombre" name="nombre"
value="<?php echo e(isset($producto->nombre)?$producto->nombre:old('nombre')); ?>">
<?php echo $errors->first('nombre', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="Categoria">Categoria</label>
<input type="Text" class="form-control" id="Categoria" placeholder="Categoria" name="categoria"
value="<?php echo e(isset($producto->categoria)?$producto->categoria:old('categoria')); ?>">
<?php echo $errors->first('categoria', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="Existencias">Existencias</label>
<input type="number" class="form-control" id="Existencias" placeholder="Existencias" name="existencias"
value="<?php echo e(isset($producto->existencias)?$producto->existencias:old('existencias')); ?>">
<?php echo $errors->first('existencias', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="Descripcion">Descripcion</label>
<input type="Text" class="form-control" id="Descripcion" placeholder="Descripcion" name="descripcion"
value="<?php echo e(isset($producto->descripcion)?$producto->descripcion:old('descripcion')); ?>">
<?php echo $errors->first('descripcion', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="precio">Precio</label>
<input type="number" class="form-control" id="precio" placeholder="precio" name="precio"
value="<?php echo e(isset($producto->precio)?$producto->precio:old('precio')); ?>">
<?php echo $errors->first('precio', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<label for="Marca">Marca</label>
<input type="Text" class="form-control" id="Marca" placeholder="Marca" name="marca"
value="<?php echo e(isset($producto->marca)?$producto->marca:old('marca')); ?>">
<?php echo $errors->first('marca', '<div class="invalid-feedback alert alert-danger" role="alert">:message</div>'); ?>


<br/>
<button type="submit" class="btn btn-default"><?php echo e($Modo=='crear' ? 'Añadir':'Guardar cambios'); ?></button>
<a href="<?php echo e(url('/productos')); ?>">
	<button type="button" class="btn btn-default">Cancelar</button>
</a><?php /**PATH C:\Users\alexis\Desktop\ProyectoIngSoft\resources\views/productos/form.blade.php ENDPATH**/ ?>