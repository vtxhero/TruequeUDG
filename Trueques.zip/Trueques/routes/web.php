<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('inicio');
});

Route::get('/gerente', function () {
    return view('gerente/login');
});
Route::get('/tecnico', function () {
    return view('tecnico/login');
});
Route::get('/almacenista', function () {
    return view('almacenista/login');
});




Route::resource('student','StudentController');

//Route::resource('','Controller');
Route::resource('insumo','insumoController');
Route::resource('empleado','empleadoController');
Route::resource('cliente','clienteController');
Route::resource('ordenser','ordenserController');
Route::resource('insumoor','insumoorController');






